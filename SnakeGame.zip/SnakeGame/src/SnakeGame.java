import java.awt.BorderLayout;

import java.awt.*;
import java.util.*;
import java.awt.EventQueue;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.Area;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class SnakeGame extends JFrame {
	
	public static boolean direita =false;
	public static boolean esquerda =false;
	public static boolean cima =false;
	public static boolean baixo =false;
	public static int x = 500;
	public static int y = 0;
	public static int n =0;
	
	
	
	
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SnakeGame frame = new SnakeGame();
					frame.setUndecorated(true);
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);

					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		});
	}
				
		public boolean intersects(JLabel i1, JLabel i2) {
			 
			 Area areai1= new Area (i1.getBounds());
			 Area areai2= new Area (i2.getBounds());

			 return areai1.intersects(areai2.getBounds2D());		 
		 }
		public void Maca() 
		{

			
			Random rnd = new Random();

			x = rnd.nextInt(740)+20;
			y =rnd.nextInt(740)+20;	
			
		}
	


	
	
	
	
	public SnakeGame() {
		
		Timer tm = new Timer();		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0)));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCabeca = new JLabel("Cabe\u00E7a");
		lblCabeca.setIcon(new ImageIcon("C:\\Users\\117778\\Desktop\\vermelho.jpg"));
		lblCabeca.setBounds(20, 20, 20, 20);
		contentPane.add(lblCabeca);
		
		JLabel lblMaca = new JLabel("maca");
		lblMaca.setIcon(new ImageIcon("Z:\\Java\\Imagens\\apple.png"));
		lblMaca.setBounds(300, 30, 20, 20);
		contentPane.add(lblMaca);

	
		
		tm.schedule(new TimerTask() {
			
			
			public void run() {
				
			
		
				if (baixo == true) {
			
					lblCabeca.setLocation(lblCabeca.getX(),lblCabeca.getY()+20);
                   
					if (intersects(lblCabeca,lblMaca)){
						Maca();
						
					}
					
                        if (lblCabeca.getY() > 770) {
	  
							lblMaca.setVisible(false);

						tm.cancel();
						
					}
					
				}else if (direita == true) {
					
					lblCabeca.setLocation(lblCabeca.getX()+20,lblCabeca.getY());
					
					if (intersects(lblCabeca,lblMaca)){
						
						Maca();
						lblMaca.setLocation(x,y);


					}
					
							
                     if (lblCabeca.getX() > 770) {
						lblMaca.setVisible(false);

						tm.cancel();
						
					}
				}else if (esquerda == true) {
					
					lblCabeca.setLocation(lblCabeca.getX()-20,lblCabeca.getY());
					
                     if (intersects(lblCabeca,lblMaca)){
						
					Maca();
					lblMaca.setLocation(x,y);


					}
                     
					if (lblCabeca.getX() < 20) {
						lblMaca.setVisible(false);

						tm.cancel();
						
					}
					
				}else if (cima == true) {
					
					lblCabeca.setLocation(lblCabeca.getX(),lblCabeca.getY()-20);
					
                     if (intersects(lblCabeca,lblMaca)){
						
 						Maca();
 						lblMaca.setLocation(x,y);
 				

					}
                     
							if (lblCabeca.getY() < 20) {
								lblMaca.setVisible(false);
								tm.cancel();
								
							}
				
				}
			}
	}, 100, 100);
		
		
		addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent ke) {
				
				if (ke.getKeyCode() == KeyEvent.VK_ESCAPE) {
					
					System.exit(0);
					
				}
				if (ke.getKeyCode() == KeyEvent.VK_DOWN) {
					
					direita = false;
					esquerda = false;
					baixo=true;
					cima=false;
			
				}else if (ke.getKeyCode() == KeyEvent.VK_LEFT) {
					
					direita = false;
					esquerda = true;
					baixo=false;
					cima=false;
	
             
					}else if (ke.getKeyCode() == KeyEvent.VK_RIGHT) {
						
						direita = true;
						esquerda = false;
						baixo=false;
						cima=false;

					}else if (ke.getKeyCode() == KeyEvent.VK_UP)  {
						
						cima=true;
						direita = false;
						esquerda = false;
						baixo=false;
						
						

						
					}
				
			
			
					
				}
					
		});

	}
	
}


