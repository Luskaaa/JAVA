package jogoLKC;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.Area;
import java.util.*;
import java.awt.Frame;
import java.awt.*;
public class lvl1 extends JFrame {
	boolean sentido=false;
	public static int morte = 0;
	public static int score = 0;
	public static int  velocidade=20;
	public static int  velocidadeIni =20;



	private JPanel contentPane;
	private JLabel lblMortes;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					lvl1 frame = new lvl1();
					frame.setUndecorated(true);
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	 public boolean intersects(JLabel i1, JLabel i2) {
		 
		 Area areai1= new Area (i1.getBounds());
		 Area areai2= new Area (i2.getBounds());

		 return areai1.intersects(areai2.getBounds2D());		 
	 }
	 
	 public boolean intersects2(JLabel i1, JPanel i2) {
		 
		 Area areai1= new Area (i1.getBounds());
		 Area areai2= new Area (i2.getBounds());
		 
		 return areai1.intersects(areai2.getBounds2D());		 

	 }


	public lvl1() {
		Timer tm = new Timer();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1440, 900);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblMortes = new JLabel("Mortes : ");
		lblMortes.setBounds(10, 11, 140, 25);
		contentPane.add(lblMortes);
		lblMortes.setFont(new Font("Tahoma", Font.PLAIN, 20));
		
		JLabel personagem = new JLabel("Personagem");
		personagem.setIcon(new ImageIcon("Z:\\Java\\Imagens\\tricoline-lisa-100-algodao-tricoline-lisa-100-algodao-vermelho-1909-50cm-x-1-50mt-1496167125234.jpg"));
		personagem.setBounds(10, 350, 50, 50);
		contentPane.add(personagem);
		
		JLabel inimigo = new JLabel("inimigo");
		inimigo.setIcon(new ImageIcon("Z:\\Java\\Imagens\\abc.jpg"));
		inimigo.setBounds(365, 0, 50, 78);
		contentPane.add(inimigo);
		
		JLabel inimigo2 = new JLabel("inimigo2");
		inimigo2.setIcon(new ImageIcon("Z:\\Java\\Imagens\\abc.jpg"));
		inimigo2.setBounds(714, 783, 50, 78);
		contentPane.add(inimigo2);
		
		JLabel inimigo3 = new JLabel("inimigo3");
		inimigo3.setIcon(new ImageIcon("Z:\\Java\\Imagens\\abc.jpg"));
		inimigo3.setBounds(1060, 0, 50, 78);
		contentPane.add(inimigo3);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.GREEN);
		panel.setForeground(Color.GREEN);
		panel.setBounds(1300, 0, 204, 900);
		contentPane.add(panel);
		
		JLabel lblScore = new JLabel("Pontos : ");
		lblScore.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblScore.setBounds(10, 47, 121, 25);
		contentPane.add(lblScore);
		
		JLabel inimigo4 = new JLabel("inimigo4");
		inimigo4.setIcon(new ImageIcon("Z:\\Java\\Imagens\\abc.jpg"));
		inimigo4.setBounds(1208, 162, 78, 50);
		contentPane.add(inimigo4);
		
		
		
		
		
		tm.schedule(new TimerTask() {
		
			public void run() {
			 if (intersects2(personagem,panel)) {
				
				score++;		
				velocidadeIni = velocidadeIni + 10;
			    lblScore.setText("Pontos: "+ score);		
				personagem.setLocation(10, 350);
			 }
				if(inimigo.getY()<0) {
					sentido=true;
				} else if (inimigo.getY()>840) {
					sentido=false;
				}
				
				if (sentido==true) {
					inimigo.setLocation(inimigo.getX(), inimigo.getY()+(velocidadeIni+80));
					inimigo2.setLocation(inimigo2.getX(), inimigo2.getY()-(velocidadeIni+80));
					inimigo3.setLocation(inimigo3.getX(), inimigo3.getY()+(velocidadeIni+80));
					if (intersects(personagem,inimigo) || intersects(personagem,inimigo2) || intersects(personagem,inimigo3)) { 
						morte++;
						lblMortes.setText("Mortes: "+ morte);
						personagem.setLocation(10, 350);
						
					

					}
		{
					}
				}else if (sentido==false) {
					
					inimigo.setLocation(inimigo.getX(), inimigo.getY()-(velocidadeIni+80));
					inimigo2.setLocation(inimigo2.getX(), inimigo2.getY()+(velocidadeIni+80));
					inimigo3.setLocation(inimigo3.getX(), inimigo3.getY()-(velocidadeIni+80));
					if (intersects(personagem,inimigo) || intersects(personagem,inimigo2) || intersects(personagem,inimigo3)) { 
						morte++;
						lblMortes.setText("Mortes: "+ morte);
						personagem.setLocation(10, 350);

					}
					
				}
			}
			
		}, 100, 100);
		
		addKeyListener(new KeyAdapter() {
			@Override
			
			// CONTROLE PARA AS SETAS
			public void keyPressed(KeyEvent ke) {
				if (ke.getKeyCode() == KeyEvent.VK_S||ke.getKeyCode() == KeyEvent.VK_DOWN) {
					if (personagem.getY() > 840 ) {
						
					}else {
					
						personagem.setLocation(personagem.getX(),personagem.getY()+velocidade);
					
						
					
					repaint();
				}
					
				}else if (ke.getKeyCode() == KeyEvent.VK_A||ke.getKeyCode() == KeyEvent.VK_LEFT) {
					if (personagem.getX() < 10) {
						
					}else {
						personagem.setLocation(personagem.getX()-velocidade,personagem.getY());
						
					repaint();
					}	
					
					
				}else if (ke.getKeyCode() == KeyEvent.VK_D||ke.getKeyCode() == KeyEvent.VK_RIGHT) {
					
					if (personagem.getX() > 1380 ) {
						
					}else {
						personagem.setLocation(personagem.getX()+velocidade,personagem.getY());
						
						repaint();
					}
					
				}else if (ke.getKeyCode() == KeyEvent.VK_W ||ke.getKeyCode() == KeyEvent.VK_UP)  {
					if (personagem.getY() < 10) {
						
					}else {
						personagem.setLocation(personagem.getX(),personagem.getY()-velocidade);
						
						repaint();
					}
				}
				//COMANDO PARA FECHAR O JOGO COM O ESC
				if (ke.getKeyCode() == KeyEvent.VK_ESCAPE) {
					
					
					System.exit(0);
					
				}
				
				
			}
		});
		
		
	}
}
