import java.awt.geom.Area;
import java.awt.image.BufferedImage;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.*;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class SnakeGame extends JFrame {
	
	public static boolean direita =false;
	public static boolean esquerda =false;
	public static boolean cima =false;
	public static boolean baixo =false;
	public static int x = 500;
	public static int y = 0;
	public static int n =0;
	public static int contl =0;
	public static int contp =0;
	public static int[][] cobra = new int[100][2];
    public static String straux;
	private JPanel contentPane;
	private BufferedImage image;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SnakeGame frame = new SnakeGame();
					frame.setUndecorated(true);
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}
	public boolean intersects(JLabel i1, JLabel i2) {
		 
		 Area areai1= new Area (i1.getBounds());
		 Area areai2= new Area (i2.getBounds());

		 return areai1.intersects(areai2.getBounds2D());		 
	 }
	
	public void Maca() 
	{

		
		Random rnd = new Random();

		x = rnd.nextInt(740)+20;
		y =rnd.nextInt(740)+20;	
		
	}

public SnakeGame() {
		
		Timer tm = new Timer();		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 800);
		contentPane = new JPanel();
		contentPane.setBorder(new LineBorder(new Color(0, 0, 0)));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCabeca = new JLabel("Cabe\u00E7a");
		lblCabeca.setIcon(new ImageIcon("C:\\Users\\117778\\Desktop\\vermelho.jpg"));
		lblCabeca.setBounds(395, 395, 30, 30);
		contentPane.add(lblCabeca);
		
		JLabel lblMaca = new JLabel("maca");
		lblMaca.setIcon(new ImageIcon("C:\\Users\\117778\\Desktop\\vermelho.jpg"));
		lblMaca.setBounds(300, 30, 20, 20);
		contentPane.add(lblMaca);
		
		JLabel lblAsdad = new JLabel("asdad");
		lblAsdad.setBounds(540, 315, 148, 113);
		contentPane.add(lblAsdad);
		
		JLabel lblcorpo = new JLabel("corpo");
		lblcorpo.setIcon(new ImageIcon("Z:\\Java\\Imagens\\abc.jpg"));
		contentPane.add(lblcorpo);
		
		tm.schedule(new TimerTask() {
			
			
			public void run() {
				
			
		
				if (baixo == true) {
			
					lblCabeca.setLocation(lblCabeca.getX(),lblCabeca.getY()+20);
                   
					if (intersects(lblCabeca,lblMaca)){
						Maca();
						
					}
					
                        if (lblCabeca.getY() > 790) {
        					lblCabeca.setLocation(lblCabeca.getX(),lblCabeca.getY()-20);

							lblMaca.setVisible(false);

						tm.cancel();
						
					}
					
				}else if (direita == true) {
					
				lblCabeca.setLocation(lblCabeca.getX()+20,lblCabeca.getY());
					
					if (intersects(lblCabeca,lblMaca)){
						
						Maca();
						
						lblMaca.setLocation(x,y);
						
	
                        cobra[contl][0] = (lblCabeca.getX()-50);
                       
                        cobra[contl][1] = (lblCabeca.getY());  
                    	
                       lblcorpo.setBounds(cobra[contl][0], cobra[contl][1], 30, 30); 
                    	 contl++;
						
					}
					
					 
						lblcorpo.setLocation(lblcorpo.getX()+20,lblcorpo.getY());
							
                     if (lblCabeca.getX() > 760) {
						lblMaca.setVisible(false);

						tm.cancel();
						
					}
				}else if (esquerda == true) {
					
					lblCabeca.setLocation(lblCabeca.getX()-20,lblCabeca.getY());
					
                     if (intersects(lblCabeca,lblMaca)){
						
					Maca();
					lblMaca.setLocation(x,y);
					
					Graphics g = getGraphics();	
					
					

					}
                    
					if (lblCabeca.getX() < 10) {
						lblMaca.setVisible(false);

						tm.cancel();
						
					}
					
				}else if (cima == true) {
					
					lblCabeca.setLocation(lblCabeca.getX(),lblCabeca.getY()-20);
					
                     if (intersects(lblCabeca,lblMaca)){
						
 						Maca();
 						lblMaca.setLocation(x,y);
 				

					}
                    
							if (lblCabeca.getY() < 10) {
								lblMaca.setVisible(false);
								tm.cancel();
								
							}
				
				}
			}
	}, 100, 100);
		
		
		addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent ke) {
				
				if (ke.getKeyCode() == KeyEvent.VK_ESCAPE) {
					
					System.exit(0);
					
				}
				if (ke.getKeyCode() == KeyEvent.VK_DOWN) {
					if (cima==true) {
						baixo=false;
					}else {
					direita = false;
					esquerda = false;
					baixo=true;
					cima=false;
				}
					
				}else if (ke.getKeyCode() == KeyEvent.VK_LEFT) {
					if (direita==true) {
					esquerda=false;
					}else {
					direita = false;
					esquerda = true;
					baixo=false;
					cima=false;
					}
             
					}else if (ke.getKeyCode() == KeyEvent.VK_RIGHT) {
						if (esquerda==true) {
							direita=false;
						}else {
						direita = true;
						esquerda = false;
						baixo=false;
						cima=false;
						}
						
					}else if (ke.getKeyCode() == KeyEvent.VK_UP)  {
						if (baixo==true) {
							cima=false;
						}else {
						cima=true;
						direita = false;
						esquerda = false;
						baixo=false;
						
					}

						
					}
				
			
			
					
				}
					
		});

	}


}
